package com.example.safing.VO;

public class MemberVO {
    private String member_id	 	;
    private String member_pw		;
    private String member_name	  	;
    private int    member_age	 	;
    private String member_gender	;
    private String member_admin		;
    private String member_filename	;
    private String member_filepath	;

    public String getMember_id() {
        return member_id;
    }
    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }
    public String getMember_pw() {
        return member_pw;
    }
    public void setMember_pw(String member_pw) {
        this.member_pw = member_pw;
    }
    public String getMember_name() {
        return member_name;
    }
    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }
    public int getMember_age() {
        return member_age;
    }
    public void setMember_age(int member_age) {
        this.member_age = member_age;
    }
    public String getMember_gender() {
        return member_gender;
    }
    public void setMember_gender(String member_gender) {
        this.member_gender = member_gender;
    }
    public String getMember_admin() {
        return member_admin;
    }
    public void setMember_admin(String member_admin) {
        this.member_admin = member_admin;
    }
    public String getMember_filename() {
        return member_filename;
    }
    public void setMember_filename(String member_filename) {
        this.member_filename = member_filename;
    }
    public String getMember_filepath() {
        return member_filepath;
    }
    public void setMember_filepath(String member_filepath) {
        this.member_filepath = member_filepath;
    }


}
