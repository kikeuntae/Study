package com.example.safing.VO;

public class Board_TagVO {
    private int		tag_num	    ;
    private int		board_id	;
    private int		cm_id	   	;
    private int		package_num	;
    private int		product_num	;
    private String	tag_key	   	;

    public int getTag_num() {
        return tag_num;
    }
    public void setTag_num(int tag_num) {
        this.tag_num = tag_num;
    }
    public int getBoard_id() {
        return board_id;
    }
    public void setBoard_id(int board_id) {
        this.board_id = board_id;
    }
    public int getCm_id() {
        return cm_id;
    }
    public void setCm_id(int cm_id) {
        this.cm_id = cm_id;
    }
    public int getPackage_num() {
        return package_num;
    }
    public void setPackage_num(int package_num) {
        this.package_num = package_num;
    }
    public int getProduct_num() {
        return product_num;
    }
    public void setProduct_num(int product_num) {
        this.product_num = product_num;
    }
    public String getTag_key() {
        return tag_key;
    }
    public void setTag_key(String tag_key) {
        this.tag_key = tag_key;
    }
}
