package com.example.safing.DTO;

import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Movie_pagerDTO {
    TextView movie_pager_tv1, movie_pager_tv2, movie_pager_tv3, movie_pager_tv4;
}
