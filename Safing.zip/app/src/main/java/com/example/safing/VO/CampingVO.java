package com.example.safing.VO;

public class CampingVO {
    private int		cm_id	      ;
    private String	cm_latitude	  ;
    private String	cm_longitude  ;
    private String	cm_addr	      ;
    private String	cm_tel	      ;
    private String	cm_img	      ;
    private String	cm_content    ;
    private String	cm_sfzone	  ;
    private String	cm_kind	      ;

    public int getCm_id() {
        return cm_id;
    }
    public void setCm_id(int cm_id) {
        this.cm_id = cm_id;
    }
    public String getCm_latitude() {
        return cm_latitude;
    }
    public void setCm_latitude(String cm_latitude) {
        this.cm_latitude = cm_latitude;
    }
    public String getCm_longitude() {
        return cm_longitude;
    }
    public void setCm_longitude(String cm_longitude) {
        this.cm_longitude = cm_longitude;
    }
    public String getCm_addr() {
        return cm_addr;
    }
    public void setCm_addr(String cm_addr) {
        this.cm_addr = cm_addr;
    }
    public String getCm_tel() {
        return cm_tel;
    }
    public void setCm_tel(String cm_tel) {
        this.cm_tel = cm_tel;
    }
    public String getCm_img() {
        return cm_img;
    }
    public void setCm_img(String cm_img) {
        this.cm_img = cm_img;
    }
    public String getCm_content() {
        return cm_content;
    }
    public void setCm_content(String cm_content) {
        this.cm_content = cm_content;
    }
    public String getCm_sfzone() {
        return cm_sfzone;
    }
    public void setCm_sfzone(String cm_sfzone) {
        this.cm_sfzone = cm_sfzone;
    }
    public String getCm_kind() {
        return cm_kind;
    }
    public void setCm_kind(String cm_kind) {
        this.cm_kind = cm_kind;
    }


}
