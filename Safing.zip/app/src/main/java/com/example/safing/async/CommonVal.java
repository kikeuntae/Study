package com.example.safing.async;

import com.example.safing.VO.MemberVO;

public class CommonVal {
    public static MemberVO loginInfo;

}
